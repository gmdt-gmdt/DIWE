from rest_framework import serializers
from api_app.models import Patient, HealthCareDetails, Guide


class PatientSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Patient
        fields = ['patient_id','last_name','first_name','blood'] 

class HealthCareDetailsSerializer(serializers.HyperlinkedModelSerializer):
    fk = PatientSerializer() 
   
    class Meta:
        model = HealthCareDetails
        fields = ['healthcare_id','healthcarenumber', 'physician', 'fk']

class GuideSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Guide
        fields = ['guide_id','firstName', 'lastName', 'designation', 'socialNetworks', 'image']
