from django.shortcuts import render
from rest_framework import viewsets
from api_app.models import Patient, HealthCareDetails, Guide
from api_app.serializers import  HealthCareDetailsSerializer, PatientSerializer, GuideSerializer


def home(request):
    hc=HealthCareDetails.objects.all()
    return render(request, 'home.html',{'hc':hc})

class HealthCareDetailsViewSet(viewsets.ModelViewSet):
    queryset= HealthCareDetails.objects.all()
    serializer_class = HealthCareDetailsSerializer

class PatientViewSet(viewsets.ModelViewSet):
    queryset= Patient.objects.all()
    serializer_class = PatientSerializer

class GuideViewSet(viewsets.ModelViewSet):
    queryset= Guide.objects.all()
    serializer_class = GuideSerializer
